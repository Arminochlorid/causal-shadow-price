# Expected Results

These JSON files contain the exact numerical results reported in Table 2 of
the paper, produced by running the corresponding coverage scripts with
B=500 replications on seeds 10000-10499.

After running e.g. `coverage_n2000_sandwich_500reps.py`, compare your
`results_n2000_500reps.json` to `expected_results/n2000_500reps.json`.
Differences within numpy/sklearn version-specific numerical precision are
expected; differences larger than 0.001 on coverage rates indicate either
a setup issue or a genuinely different sklearn version.

The COMPAS notebooks do not produce JSON outputs; the expected values for
Section 10.3 are documented inline in `compas/compas_step2.ipynb`.
